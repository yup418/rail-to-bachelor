globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2139e000f4b5d584.js",
    "static/chunks/ab1d2a5ce03b1e0b.js",
    "static/chunks/9712fa19554405f9.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/turbopack-74fa04a2922a8aa9.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];
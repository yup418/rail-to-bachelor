var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/mistakes/route.js")
R.c("server/chunks/[root-of-the-server]__3975a4e6._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_mistakes_route_actions_56132657.js")
R.m(86191)
module.exports=R.m(86191).exports

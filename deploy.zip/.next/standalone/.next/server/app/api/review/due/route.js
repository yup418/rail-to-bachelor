var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/review/due/route.js")
R.c("server/chunks/[root-of-the-server]__13d5af9b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_review_due_route_actions_f627abd5.js")
R.m(82513)
module.exports=R.m(82513).exports

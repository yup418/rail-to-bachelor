var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/daily-task/route.js")
R.c("server/chunks/[root-of-the-server]__a98c1b56._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_daily-task_route_actions_88d2afab.js")
R.m(40915)
module.exports=R.m(40915).exports

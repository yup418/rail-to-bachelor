var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/quiz/submit/route.js")
R.c("server/chunks/[root-of-the-server]__bac96151._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_quiz_submit_route_actions_29688302.js")
R.m(44232)
module.exports=R.m(44232).exports

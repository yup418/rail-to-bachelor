var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/import/route.js")
R.c("server/chunks/[root-of-the-server]__8aad5372._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_import_route_actions_fd6c2005.js")
R.m(83557)
module.exports=R.m(83557).exports

var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/papers/[id]/progress/route.js")
R.c("server/chunks/[root-of-the-server]__9239b2ac._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_papers_[id]_progress_route_actions_a8aa4ad3.js")
R.m(72993)
module.exports=R.m(72993).exports

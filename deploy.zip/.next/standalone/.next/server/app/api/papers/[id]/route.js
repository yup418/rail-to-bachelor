var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/papers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__a9572d38._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_papers_[id]_route_actions_2d2caff9.js")
R.m(66158)
module.exports=R.m(66158).exports

var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/papers/route.js")
R.c("server/chunks/[root-of-the-server]__7c0d0d91._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_papers_route_actions_d3e694c8.js")
R.m(60158)
module.exports=R.m(60158).exports

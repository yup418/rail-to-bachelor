var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/password/route.js")
R.c("server/chunks/[root-of-the-server]__b01ab6e1._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__ff65a18c._.js")
R.c("server/chunks/_next-internal_server_app_api_user_password_route_actions_a589ab2b.js")
R.m(62342)
module.exports=R.m(62342).exports

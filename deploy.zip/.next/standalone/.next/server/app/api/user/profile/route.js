var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/profile/route.js")
R.c("server/chunks/[root-of-the-server]__87115998._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_user_profile_route_actions_3aeda26f.js")
R.m(20891)
module.exports=R.m(20891).exports

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__bab7ae82._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register_route_actions_3564e727.js")
R.m(6706)
module.exports=R.m(6706).exports

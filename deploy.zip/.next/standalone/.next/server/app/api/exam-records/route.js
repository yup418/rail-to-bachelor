var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/exam-records/route.js")
R.c("server/chunks/[root-of-the-server]__a147c97f._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_exam-records_route_actions_5853095d.js")
R.m(9114)
module.exports=R.m(9114).exports

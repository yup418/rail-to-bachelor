var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/exam-records/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__56b47121._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__f9168631._.js")
R.c("server/chunks/_next-internal_server_app_api_exam-records_[id]_route_actions_5ba79982.js")
R.m(82431)
module.exports=R.m(82431).exports

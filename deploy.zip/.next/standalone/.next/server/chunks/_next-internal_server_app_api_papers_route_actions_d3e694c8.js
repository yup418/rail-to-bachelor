module.exports=[55758,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_papers_route_actions_d3e694c8.js.map
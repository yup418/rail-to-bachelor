module.exports=[42494,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_questions_%5Bid%5D_route_actions_a0f715a2.js.map
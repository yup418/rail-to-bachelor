module.exports=[94904,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_exam-records_route_actions_5853095d.js.map
module.exports=[41481,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_quiz_submit_route_actions_29688302.js.map
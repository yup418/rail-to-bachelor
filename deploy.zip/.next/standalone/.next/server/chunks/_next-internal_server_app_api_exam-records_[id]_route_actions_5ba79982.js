module.exports=[9214,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_exam-records_%5Bid%5D_route_actions_5ba79982.js.map
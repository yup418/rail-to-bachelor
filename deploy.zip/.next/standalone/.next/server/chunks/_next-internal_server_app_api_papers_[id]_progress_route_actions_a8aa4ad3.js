module.exports=[10744,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_papers_%5Bid%5D_progress_route_actions_a8aa4ad3.js.map
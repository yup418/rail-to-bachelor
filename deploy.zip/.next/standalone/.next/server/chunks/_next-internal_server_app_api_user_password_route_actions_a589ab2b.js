module.exports=[84408,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_password_route_actions_a589ab2b.js.map
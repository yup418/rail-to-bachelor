module.exports=[55376,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mistakes_%5Bid%5D_page_actions_9b75f102.js.map
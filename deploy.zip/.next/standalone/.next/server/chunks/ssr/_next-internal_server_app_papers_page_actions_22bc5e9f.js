module.exports=[19501,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_papers_page_actions_22bc5e9f.js.map
module.exports=[63730,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_import_page_actions_264b2b59.js.map
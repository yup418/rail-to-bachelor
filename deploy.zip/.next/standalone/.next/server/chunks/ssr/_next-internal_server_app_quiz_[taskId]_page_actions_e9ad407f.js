module.exports=[42479,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_quiz_%5BtaskId%5D_page_actions_e9ad407f.js.map
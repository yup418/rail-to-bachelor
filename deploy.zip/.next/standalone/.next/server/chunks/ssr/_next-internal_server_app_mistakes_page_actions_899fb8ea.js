module.exports=[45806,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mistakes_page_actions_899fb8ea.js.map
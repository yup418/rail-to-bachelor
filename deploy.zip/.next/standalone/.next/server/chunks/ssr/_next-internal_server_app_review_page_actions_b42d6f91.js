module.exports=[92795,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_review_page_actions_b42d6f91.js.map
module.exports=[4886,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_records_page_actions_3d383ac1.js.map
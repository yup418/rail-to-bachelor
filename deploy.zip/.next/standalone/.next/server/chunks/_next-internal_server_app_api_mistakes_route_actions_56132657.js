module.exports=[42733,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mistakes_route_actions_56132657.js.map
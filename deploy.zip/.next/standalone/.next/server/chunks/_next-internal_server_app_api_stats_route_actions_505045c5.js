module.exports=[21894,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stats_route_actions_505045c5.js.map
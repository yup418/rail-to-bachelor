-- AlterTable
ALTER TABLE "ExamPaper" ADD COLUMN     "paperType" TEXT NOT NULL DEFAULT 'REAL';
